-- RPC: get_chandrashtama_days
CREATE OR REPLACE FUNCTION get_chandrashtama_days(
  user_nakshatra TEXT,
  start_date DATE DEFAULT CURRENT_DATE,
  end_date DATE DEFAULT CURRENT_DATE + INTERVAL '30 days'
)
RETURNS TABLE(date DATE, main_nakshatra TEXT, formatted_nakshatra TEXT)
LANGUAGE sql
AS $$
  SELECT
    date,
    main_nakshatra,
    main_nakshatra AS formatted_nakshatra
  FROM daily_panchangam
  WHERE
    user_nakshatra = ANY (
      SELECT jsonb_array_elements_text(chandrashtama_for)
    )
    AND date BETWEEN start_date AND end_date
  ORDER BY date;
$$;