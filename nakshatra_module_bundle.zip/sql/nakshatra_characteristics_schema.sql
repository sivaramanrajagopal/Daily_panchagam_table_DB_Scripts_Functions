-- Add columns if not present
ALTER TABLE nakshatra_characteristics ADD COLUMN IF NOT EXISTS ruler TEXT;
ALTER TABLE nakshatra_characteristics ADD COLUMN IF NOT EXISTS ruler_tamil TEXT;

-- Update planetary rulers (English and Tamil)
UPDATE nakshatra_characteristics SET ruler = 'Ketu', ruler_tamil = 'கேது' WHERE english_name = 'Ashwini';
UPDATE nakshatra_characteristics SET ruler = 'Venus', ruler_tamil = 'சுக்கிரன்' WHERE english_name = 'Bharani';
...
UPDATE nakshatra_characteristics SET ruler = 'Mercury', ruler_tamil = 'புதன்' WHERE english_name = 'Revati';